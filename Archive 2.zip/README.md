initial readme commit
